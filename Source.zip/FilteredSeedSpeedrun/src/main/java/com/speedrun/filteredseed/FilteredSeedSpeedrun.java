package com.speedrun.filteredseed;

import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class FilteredSeedSpeedrun extends JavaPlugin implements Listener {

    private final Set<UUID> frozenPlayers = new HashSet<>();
    private final Map<String, String> FILTERS = new HashMap<>();
    private final Map<UUID, SpeedrunSession> activeSessions = new ConcurrentHashMap<>();

    public FilteredSeedSpeedrun() {
        FILTERS.put("bt", "zsg");
        FILTERS.put("btop", "zsgop");
        FILTERS.put("village", "zsgvillage");
        FILTERS.put("villageop", "zsgvillageop");
        FILTERS.put("temple", "zsgtemple");
        FILTERS.put("templeop", "zsgtempleop");
        FILTERS.put("ship", "zsgshipwreck");
        FILTERS.put("shipop", "zsgshipwreckop");
        FILTERS.put("rp", "rpseedbank");
    }

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("FilteredSeedSpeedrun enabled - Using filteredseed.com API");
    }

    @Override
    public void onDisable() {
        // Cleanup all sessions
        for (SpeedrunSession session : activeSessions.values()) {
            cleanupSession(session);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cPlayers only.");
            return true;
        }

        if (!command.getName().equalsIgnoreCase("fsspeedrun")) {
            return false;
        }

        Player player = (Player) sender;

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help":
                sendHelp(player);
                break;
            case "start":
                handleStart(player, args);
                break;
            case "join":
                handleJoin(player, args);
                break;
            case "leave":
                handleLeave(player);
                break;
            case "filters":
                listFilters(player);
                break;
            default:
                sendHelp(player);
        }
        return true;
    }

    private void handleStart(Player player, String[] args) {
        if (activeSessions.containsKey(player.getUniqueId())) {
            player.sendMessage("§cYou already have an active speedrun session!");
            player.sendMessage("§eUse /fsspeedrun leave to end it first");
            return;
        }

        String alias = args.length >= 2 ? args[1].toLowerCase() : "village";
        boolean coopMode = args.length >= 3 && args[2].equalsIgnoreCase("coop");

        String filterId = FILTERS.get(alias);
        if (filterId == null) {
            player.sendMessage("§cUnknown filter: '" + alias + "'");
            player.sendMessage("§eUse /fsspeedrun filters to see available options");
            return;
        }

        startRun(player, filterId, alias, coopMode);
    }

    private void handleJoin(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§cUsage: /fsspeedrun join <player>");
            return;
        }

        Player host = Bukkit.getPlayer(args[1]);
        if (host == null) {
            player.sendMessage("§cPlayer not found!");
            return;
        }

        SpeedrunSession session = activeSessions.get(host.getUniqueId());
        if (session == null) {
            player.sendMessage("§cThat player doesn't have an active speedrun!");
            return;
        }

        if (!session.coopMode) {
            player.sendMessage("§cThat speedrun is solo-only!");
            return;
        }

        // Add player to session
        session.participants.add(player.getUniqueId());
        activeSessions.put(player.getUniqueId(), session);

        // Teleport to the overworld
        player.teleport(session.overworld.getSpawnLocation());
        player.setGameMode(GameMode.SURVIVAL);
        player.getInventory().clear();

        player.sendMessage("§aJoined " + host.getName() + "'s speedrun!");
        host.sendMessage("§e" + player.getName() + " joined your speedrun!");
    }

    private void handleLeave(Player player) {
        SpeedrunSession session = activeSessions.remove(player.getUniqueId());

        if (session == null) {
            player.sendMessage("§cYou don't have an active speedrun!");
            return;
        }

        // If host is leaving, end for everyone
        if (session.host.equals(player.getUniqueId())) {
            for (UUID participantId : session.participants) {
                Player participant = Bukkit.getPlayer(participantId);
                if (participant != null && participant.isOnline()) {
                    participant.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                    participant.sendMessage("§eSpeedrun ended by host!");
                }
                activeSessions.remove(participantId);
            }
            cleanupSession(session);
            player.sendMessage("§aSpeedrun ended and worlds cleaned up!");
        } else {
            // Participant leaving
            session.participants.remove(player.getUniqueId());
            player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            player.sendMessage("§eLeft the speedrun!");

            Player host = Bukkit.getPlayer(session.host);
            if (host != null) {
                host.sendMessage("§e" + player.getName() + " left your speedrun!");
            }
        }
    }

    private void startRun(Player player, String filterID, String filterName, boolean coopMode) {
        player.sendMessage("§eRequesting filtered seed from filteredseed.com...");
        player.sendMessage("§7Filter: " + filterName + (coopMode ? " (Co-op)" : " (Solo)"));

        new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    String seed = fetchSeedFromAPI(filterID);
                    if (seed == null) {
                        player.sendMessage("§cFailed to get seed from API.");
                        return;
                    }

                    new BukkitRunnable() {
                        @Override
                        public void run() {
                            createWorldsAndTeleport(player, seed, filterName, coopMode);
                        }
                    }.runTask(FilteredSeedSpeedrun.this);

                } catch (Exception e) {
                    e.printStackTrace();
                    player.sendMessage("§cError fetching seed: " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(this);
    }

    private String fetchSeedFromAPI(String filterID) throws Exception {
        URL url = new URL("https://filteredseed.com/getRandomUsedSeed/" + filterID);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);

        if (conn.getResponseCode() != 200) return null;

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) response.append(line);
        reader.close();

        String json = response.toString();
        int index = json.indexOf("\"seed\":\"");
        if (index == -1) return null;

        int start = index + 8;
        int end = json.indexOf("\"", start);
        return json.substring(start, end);
    }

    private void createWorldsAndTeleport(Player player, String seedString, String filterName, boolean coopMode) {
        long seed;
        try {
            seed = Long.parseLong(seedString);
        } catch (NumberFormatException e) {
            seed = seedString.hashCode();
        }

        String baseName = "fss_" + player.getName() + "_" + System.currentTimeMillis();

        // Create Overworld
        WorldCreator overworldCreator = new WorldCreator(baseName)
                .environment(World.Environment.NORMAL)
                .type(WorldType.NORMAL)
                .seed(seed);
        World overworld = Bukkit.createWorld(overworldCreator);

        // Create Nether
        WorldCreator netherCreator = new WorldCreator(baseName + "_nether")
                .environment(World.Environment.NETHER)
                .type(WorldType.NORMAL)
                .seed(seed);
        World nether = Bukkit.createWorld(netherCreator);

        // Create End
        WorldCreator endCreator = new WorldCreator(baseName + "_the_end")
                .environment(World.Environment.THE_END)
                .type(WorldType.NORMAL)
                .seed(seed);
        World end = Bukkit.createWorld(endCreator);

        if (overworld == null || nether == null || end == null) {
            player.sendMessage("§cFailed to create worlds.");
            return;
        }

        // Create session
        SpeedrunSession session = new SpeedrunSession(
                player.getUniqueId(),
                overworld,
                nether,
                end,
                seed,
                filterName,
                coopMode
        );
        session.participants.add(player.getUniqueId());
        activeSessions.put(player.getUniqueId(), session);

        // Teleport and setup player
        player.teleport(overworld.getSpawnLocation());
        player.setGameMode(GameMode.SURVIVAL);
        player.getInventory().clear();

        // Display info
        player.sendMessage("§a§l═══════════════════════════════");
        player.sendMessage("§6§lSpeedrun Started!");
        player.sendMessage("§eSeed: §f" + seedString);
        player.sendMessage("§eFilter: §f" + filterName);
        player.sendMessage("§eMode: §f" + (coopMode ? "Co-op" : "Solo"));
        if (coopMode) {
            player.sendMessage("§eOthers can join: §f/fsspeedrun join " + player.getName());
        }
        player.sendMessage("§a§l═══════════════════════════════");

        // Freeze and countdown
        frozenPlayers.add(player.getUniqueId());
        startCountdown(player, 5, session);
    }

    private void startCountdown(Player player, int seconds, SpeedrunSession session) {
        new BukkitRunnable() {
            int counter = seconds;

            @Override
            public void run() {
                if (counter <= 0) {
                    frozenPlayers.remove(player.getUniqueId());
                    player.sendMessage("§aGo!");
                    // Start timer
                    session.startTime = System.currentTimeMillis();
                    startTimer(player, session);
                    cancel();
                    return;
                }
                player.sendMessage("§e" + counter + "...");
                counter--;
            }
        }.runTaskTimer(this, 0L, 20L);
    }

    private void startTimer(Player player, SpeedrunSession session) {
        // Create scoreboard
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        Scoreboard scoreboard = manager.getNewScoreboard();
        Objective objective = scoreboard.registerNewObjective("timer", "dummy", "§6§lTime");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        player.setScoreboard(scoreboard);

        // Update timer every second
        session.timerTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (session.completed || !player.isOnline()) {
                    cancel();
                    return;
                }

                long elapsed = System.currentTimeMillis() - session.startTime;
                String timeStr = formatTime(elapsed);

                // Clear old scores
                for (String entry : scoreboard.getEntries()) {
                    scoreboard.resetScores(entry);
                }

                // Set new time
                Score score = objective.getScore("§f" + timeStr);
                score.setScore(1);
            }
        }.runTaskTimer(this, 0L, 20L);
    }

    private String formatTime(long millis) {
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        seconds = seconds % 60;
        minutes = minutes % 60;

        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%d:%02d", minutes, seconds);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        // Check if frozen during countdown
        if (frozenPlayers.contains(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    private void completeSpeedrun(Player player, SpeedrunSession session) {
        session.completed = true;
        long finalTime = System.currentTimeMillis() - session.startTime;
        String timeStr = formatTime(finalTime);

        // Stop timer
        if (session.timerTask != null) {
            session.timerTask.cancel();
        }

        // Show completion messages
        player.sendMessage("");
        player.sendMessage("§6§l§m                                    ");
        player.sendMessage("§a§l         SPEEDRUN COMPLETE!         ");
        player.sendMessage("§6§l§m                                    ");
        player.sendMessage("");
        player.sendMessage("§e  Final Time: §f§l" + timeStr);
        player.sendMessage("§e  Seed: §f" + session.seed);
        player.sendMessage("§e  Filter: §f" + session.filterName);
        player.sendMessage("");
        player.sendMessage("§6§l§m                                    ");
        player.sendMessage("");

        // Play sounds and effects
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        player.sendTitle("§6§lCOMPLETE!", "§e" + timeStr, 10, 70, 20);

        // Notify other participants
        for (UUID participantId : session.participants) {
            if (!participantId.equals(player.getUniqueId())) {
                Player p = Bukkit.getPlayer(participantId);
                if (p != null && p.isOnline()) {
                    p.sendMessage("§a" + player.getName() + " completed the speedrun in " + timeStr + "!");
                }
            }
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        // Detect dragon death
        if (event.getEntity() instanceof EnderDragon) {
            World world = event.getEntity().getWorld();

            // Find which session this dragon belongs to
            for (SpeedrunSession session : activeSessions.values()) {
                if (session.end.equals(world)) {
                    session.dragonKilled = true;
                    break;
                }
            }
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        SpeedrunSession session = activeSessions.get(player.getUniqueId());

        if (session != null) {
            // Respawn in the speedrun overworld
            event.setRespawnLocation(session.overworld.getSpawnLocation());
        }
    }

    @EventHandler
    public void onPlayerPortal(PlayerPortalEvent event) {
        Player player = event.getPlayer();
        SpeedrunSession session = activeSessions.get(player.getUniqueId());

        if (session == null) return;

        World from = event.getFrom().getWorld();

        if (event.getCause() == PlayerPortalEvent.TeleportCause.NETHER_PORTAL) {
            if (from.getEnvironment() == World.Environment.NORMAL) {
                // Overworld -> Nether
                Location to = new Location(session.nether,
                        event.getFrom().getX() / 8,
                        event.getFrom().getY(),
                        event.getFrom().getZ() / 8);
                event.setTo(to);
            } else if (from.getEnvironment() == World.Environment.NETHER) {
                // Nether -> Overworld
                Location to = new Location(session.overworld,
                        event.getFrom().getX() * 8,
                        event.getFrom().getY(),
                        event.getFrom().getZ() * 8);
                event.setTo(to);
            }
        } else if (event.getCause() == PlayerPortalEvent.TeleportCause.END_PORTAL) {
            if (from.getEnvironment() == World.Environment.NORMAL) {
                // Overworld -> End
                event.setTo(session.end.getSpawnLocation());
            } else if (from.getEnvironment() == World.Environment.THE_END) {
                // End -> Overworld (the exit portal after dragon kill)
                if (session.dragonKilled && !session.completed) {
                    // Complete the speedrun!
                    completeSpeedrun(player, session);
                }
                event.setTo(session.overworld.getSpawnLocation());
            }
        }
    }

    private void cleanupSession(SpeedrunSession session) {
        // Stop timer if running
        if (session.timerTask != null) {
            session.timerTask.cancel();
        }

        // Clear scoreboards
        for (UUID participantId : session.participants) {
            Player p = Bukkit.getPlayer(participantId);
            if (p != null && p.isOnline()) {
                p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            }
        }

        // Unload and delete worlds
        unloadWorld(session.overworld);
        unloadWorld(session.nether);
        unloadWorld(session.end);
    }

    private void unloadWorld(World world) {
        if (world == null) return;

        String worldName = world.getName();
        Bukkit.unloadWorld(world, false);

        // Delete world folder
        File worldFolder = new File(Bukkit.getWorldContainer(), worldName);
        if (worldFolder.exists()) {
            deleteDirectory(worldFolder);
        }
    }

    private void deleteDirectory(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectory(file);
                } else {
                    file.delete();
                }
            }
        }
        directory.delete();
    }

    private void listFilters(Player player) {
        player.sendMessage("§a§l═══ Available FSG Filters ═══");
        player.sendMessage("§ebt §7- Buried Treasure");
        player.sendMessage("§ebtop §7- Buried Treasure (Overpowered)");
        player.sendMessage("§evillage §7- Village near spawn");
        player.sendMessage("§evillageop §7- Village (Overpowered)");
        player.sendMessage("§etemple §7- Desert Temple");
        player.sendMessage("§etempleop §7- Temple (Overpowered)");
        player.sendMessage("§eship §7- Shipwreck");
        player.sendMessage("§eshipop §7- Shipwreck (Overpowered)");
        player.sendMessage("§erp §7- Ruined Portal");
        player.sendMessage("");
        player.sendMessage("§7Example: /fsspeedrun start village");
        player.sendMessage("§7Co-op: /fsspeedrun start village coop");
    }

    private void sendHelp(Player player) {
        player.sendMessage("§6§l╔═══════════════════════════════════════╗");
        player.sendMessage("§6§l║   §e§lFiltered Seed Speedrun v1.0   §6§l║");
        player.sendMessage("§6§l╚═══════════════════════════════════════╝");
        player.sendMessage("");
        player.sendMessage("§e/fsspeedrun help");
        player.sendMessage("  §7Display this help menu");
        player.sendMessage("");
        player.sendMessage("§e/fsspeedrun start §7<filter> [coop]");
        player.sendMessage("  §7Start a speedrun with filtered seed");
        player.sendMessage("  §3Example: §f/fsspeedrun start village");
        player.sendMessage("  §3Co-op: §f/fsspeedrun start village coop");
        player.sendMessage("");
        player.sendMessage("§e/fsspeedrun join §7<player>");
        player.sendMessage("  §7Join another player's co-op speedrun");
        player.sendMessage("");
        player.sendMessage("§e/fsspeedrun leave");
        player.sendMessage("  §7Exit speedrun and cleanup worlds");
        player.sendMessage("");
        player.sendMessage("§e/fsspeedrun filters");
        player.sendMessage("  §7List all available FSG filters");
        player.sendMessage("");
        player.sendMessage("§7Seeds from: §fhttps://filteredseed.com");
        player.sendMessage("§8§m                                           ");
    }

    // Session data class
    private static class SpeedrunSession {
        UUID host;
        World overworld;
        World nether;
        World end;
        long seed;
        String filterName;
        boolean coopMode;
        Set<UUID> participants = new HashSet<>();
        long startTime = 0;
        boolean dragonKilled = false;
        boolean completed = false;
        BukkitTask timerTask = null;

        SpeedrunSession(UUID host, World overworld, World nether, World end, long seed, String filterName, boolean coopMode) {
            this.host = host;
            this.overworld = overworld;
            this.nether = nether;
            this.end = end;
            this.seed = seed;
            this.filterName = filterName;
            this.coopMode = coopMode;
        }
    }
}